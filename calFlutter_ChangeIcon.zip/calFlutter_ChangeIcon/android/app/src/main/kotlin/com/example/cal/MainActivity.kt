package com.example.cal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
