package com.example.act5jsonv2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
